# The Cyber tracks: 5 packs, how they fit together

These are 5 `kind = "proficiency"` packs (8 main levels each, one milestone per level, plus a side lane of
quick-win drills), alongside the `kind = "project"` pack you already have (`home-hack-lab`). All 5 passed a real
structural validation — unique ids, every `needs` reference resolves, no cycles, every main level has its
milestone, series expand correctly — not just eyeballed. They are still `source = "ai-draft"`, `reviewed = false`:
run `ascend pack lint` and `ascend pack check-links` on each and read every `done_when` yourself before trusting
them, exactly like every other pack in this project.

**A note on verifiers:** every `verify` block in these packs uses only `file` or `command` types — the ones
guaranteed to exist from Phase 1 onward. None of them assume a server, plugins, or the Codeforces/GitHub/Praxis
verifier types that only arrive in later phases. They'll work whatever your actual build status is.

## The 6 packs, in one table

| Pack | Kind | What it builds | Depends on |
|---|---|---|---|
| `home-hack-lab` | project | Your original Pi attack/harden project | Nothing — you've already started it |
| `networking-for-security` | proficiency | TCP/IP, DNS, packet capture, routing — the foundation everything else leans on | Nothing |
| `web-application-security` | proficiency | Full OWASP Top 10 via PortSwigger Academy, deeper than home-hack-lab's intro | `networking-for-security` (application layer) |
| `network-penetration-testing` | proficiency | nmap, Metasploit, Linux/Windows privesc, Active Directory basics | `networking-for-security` |
| `reverse-engineering-and-binary-exploitation` | proficiency | Assembly, Ghidra, GDB, stack overflows, ROP, heap bugs — the low-level track | Comfortable reading C (the first level builds the rest) |
| `defensive-security-and-detection` | proficiency | Logging, Zeek/Suricata, a SIEM, detection engineering, incident response | Benefits from running alongside `network-penetration-testing` |

## Recommended order — but remember, only ONE mission is ever active at a time

The engine only lets you run one mission at once, so "order" here just means which pack you `ascend mission start`
first, not something you have to plan out fully in advance. Suggested path:

1. **`networking-for-security` first**, always. Every other track assumes you can read a packet capture and knows
   what a three-way handshake is.
2. **Then split by what actually pulls you.** You already have real signal from this conversation: Juice Shop and
   Bandit both "felt addictive" to you. That points at `web-application-security` and the side-lane drills in
   `network-penetration-testing` as the next real candidates, not a forced linear order through all 5.
3. **Run `defensive-security-and-detection` *alongside* `network-penetration-testing`, not strictly after it.**
   Several of its nodes explicitly reuse an attack you just ran as the thing you detect — attacking something and
   immediately checking what it looked like from the defender's side, while it's fresh, is the actual point. Since
   you can only have one ACTIVE mission, the practical version of "alongside" is: finish a level or two of
   `network-penetration-testing`, switch missions, do the matching `defensive-security-and-detection` level while
   the attack is fresh in memory, switch back. Not a rule the engine enforces — just the sequencing that makes the
   content work as designed.
4. **`reverse-engineering-and-binary-exploitation` whenever the low-level pull hits.** It's the most
   self-contained of the 5 — it doesn't depend on the others — so it's the one to switch to on a night you want
   exactly that itch scratched, without it costing you progress elsewhere.

There's no "finish all 5" milestone and there shouldn't be one. These are five deep subjects, not one checklist.

## One honest caveat on the resource links

Every `resource` URL points at real, well-known, stable domains (PortSwigger, OWASP, MITRE ATT&CK, exploit.education,
ROP Emporium, Zeek/Suricata docs, nmap.org, GTFOBins, HackTricks, and similar) — these are the actual standard
references people in this field use, not invented sources. What hasn't been individually re-verified is that every
single deep link resolves to exactly the page it should — that's precisely what `ascend pack check-links` exists
to catch, so run it before trusting any pack, the same discipline already established for `home-hack-lab`.
