# Inputs for Promote and roll back

This operation uses the shared Relay/tools and commands in the lesson; no extra native input is required.

Read ../../lessons/05.md for the target machine, placeholders, controls and cleanup.
